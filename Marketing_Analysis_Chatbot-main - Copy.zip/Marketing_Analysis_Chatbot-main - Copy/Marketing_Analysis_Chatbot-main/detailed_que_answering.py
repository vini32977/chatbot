import pandas as pd
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer
import spacy
import warnings

# Suppress warnings related to transformers
warnings.filterwarnings("ignore", message="The `clean_up_tokenization_spaces`")

# Load Spacy NLP model for question filtering
nlp_spacy = spacy.load("en_core_web_sm")

# Load dataset and preprocess it
df = pd.read_csv('marketing_campaign_dataset_first2K.csv')
df.columns = df.columns.str.strip()
df['Acquisition_Cost'] = df['Acquisition_Cost'].replace(
    {'\$': '', ',': ''}, regex=True).astype(float)

# Load DialoGPT model from Hugging Face for conversational AI
tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")
model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")

# Caching previous responses
response_cache = {}

# Define a list of greetings and conversational prompts
greetings = ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "how are you"]

# Function to detect if the input is a greeting
def is_greeting(user_input):
    return user_input.lower() in greetings

# Function to generate context for marketing campaigns
def generate_context(filtered_df):
    filtered_df = filtered_df.head(10)
    context = "\n".join(
        f"Campaign ID {row['Campaign_ID']} by {row['Company']} is a {row['Campaign_Type']} campaign "
        f"targeted at {row['Target_Audience']} for {row['Duration']} days. It was conducted in "
        f"{row['Location']} using {row['Channel_Used']}. The campaign had a conversion rate of "
        f"{row['Conversion_Rate']}, an acquisition cost of ${row['Acquisition_Cost']:.2f}, and "
        f"a ROI of {row['ROI']:.2f}."
        for _, row in filtered_df.iterrows()
    )
    return context

# Function to provide a fallback response using Hugging Face's DialoGPT for open-ended questions
def dialo_gpt_fallback(question):
    inputs = tokenizer.encode(question + tokenizer.eos_token, return_tensors="pt")
    chat_history_ids = model.generate(inputs, max_length=1000, pad_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(chat_history_ids[:, inputs.shape[-1]:][0], skip_special_tokens=True)

# Function to extract an answer based on the question
def extract_answer(question):
    if question in response_cache:
        return response_cache[question]

    # Check for greetings and open-ended questions
    if is_greeting(question):
        return "Hello! How can I assist you today?"

    # Specific logic for the dataset
    if "influencer campaign" in question and "highest conversion rate" in question:
        influencer_campaigns = df[df['Campaign_Type'] == 'Influencer Marketing Campaign']
        highest_conversion_rate = influencer_campaigns['Conversion_Rate'].max()
        highest_conversion_campaign = influencer_campaigns[
            influencer_campaigns['Conversion_Rate'] == highest_conversion_rate
        ]
        if not highest_conversion_campaign.empty:
            channel_used = highest_conversion_campaign['Channel_Used'].iloc[0]
            return f"The channel used for the influencer campaign with the highest conversion rate was {channel_used}."
        else:
            return "There are no influencer campaigns with a conversion rate in the dataset."

    # Use DialoGPT for open-ended questions
    response_cache[question] = dialo_gpt_fallback(question)

    return response_cache[question]

# Function to handle "stats" action
def handle_stats():
    average_roi = df['ROI'].mean()
    average_acquisition_cost = df['Acquisition_Cost'].mean()
    print(f"Average ROI: {average_roi:.2f}")
    print(f"Average Acquisition Cost: ${average_acquisition_cost:.2f}")

# Function to handle "filter" action
def handle_filter():
    filter_criteria = input(
        "Enter filtering criteria (e.g., 'Campaign_Type == 'Social Media Campaign''): "
    )
    try:
        filtered_df = df.query(filter_criteria)
        print("Filtered data:")
        print(filtered_df)
    except ValueError:
        print("Invalid filtering criteria.")

# Function to handle "summary" action
def handle_summary():
    print(summarize_trends())

# Function to handle "trends" action
def handle_trends():
    visualize_trends()

# Function to handle "sentiment" action
def handle_sentiment():
    from textblob import TextBlob
    sentiment_results = []

    # Use 'Target_Audience' for sentiment analysis
    for _, row in df.iterrows():
        blob = TextBlob(row['Target_Audience'])
        sentiment_results.append(
            f"Campaign ID {row['Campaign_ID']}: Sentiment - Polarity: {blob.sentiment.polarity}, "
            f"Subjectivity: {blob.sentiment.subjectivity}"
        )

    print("Sentiment Analysis:")
    print("\n".join(sentiment_results))

# Main function to run the chatbot
def main():
    print("Welcome to the Real-Time Marketing Campaign Chatbot!")
    print("You can ask any question about the marketing campaigns or choose an action.")
    print("Available actions: 'stats', 'filter', 'summary', 'trends', 'sentiment', 'exit'.")

    while True:
        user_input = input("\nAsk a question or choose an action: ")

        if user_input.lower() == 'exit':
            print("Goodbye!")
            break
        elif user_input.lower() == 'stats':
            handle_stats()
        elif user_input.lower() == 'filter':
            handle_filter()
        elif user_input.lower() == 'summary':
            handle_summary()
        elif user_input.lower() == 'trends':
            handle_trends()
        elif user_input.lower() == 'sentiment':
            handle_sentiment()
        else:
            response = extract_answer(user_input)
            print(f"\nResponse: {response}")

if __name__ == '__main__':
    main()
