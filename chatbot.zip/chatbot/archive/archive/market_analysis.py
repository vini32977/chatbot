import pandas as pd

# Load the dataset in chunks to handle large data efficiently
CHUNK_SIZE = 10000  # Adjust based on memory
FILE_PATH = 'marketing_campaign_dataset.csv'  # Ensure this is the correct path to your dataset

# Initialize an empty list to store aggregated results
all_data = []


def load_data(file_path):
    """Loads dataset in chunks and processes it."""
    for chunk in pd.read_csv(file_path, chunksize=CHUNK_SIZE):
        # Pre-process acquisition cost by removing $ sign and converting to float
        chunk['Acquisition_Cost'] = chunk['Acquisition_Cost'].replace('[\$,]', '', regex=True).astype(float)
        all_data.append(chunk)

    # Concatenate all the chunks back into a single DataFrame
    return pd.concat(all_data, axis=0)


# Load the dataset
data = load_data(FILE_PATH)


def calculate_roi(campaign_id):
    """Returns ROI for a specific campaign ID."""
    campaign_data = data[data['Campaign_ID'] == campaign_id]
    if not campaign_data.empty:
        return campaign_data[['Campaign_ID', 'ROI']]
    return f"Campaign ID {campaign_id} not found."


def average_conversion_rate(channel):
    """Returns average conversion rate for a given channel."""
    channel_data = data[data['Channel_Used'] == channel]
    if not channel_data.empty:
        return channel_data['Conversion_Rate'].mean()
    return f"No data for channel {channel}."


def highest_engagement_score(segment):
    """Returns the highest engagement score for a specific customer segment."""
    segment_data = data[data['Customer_Segment'] == segment]
    if not segment_data.empty:
        return segment_data[['Campaign_ID', 'Engagement_Score']].sort_values(
            by='Engagement_Score', ascending=False).head(1)
    return f"No data for customer segment {segment}."


def bot_response(query):
    """Handles user queries and returns appropriate responses."""
    if "ROI" in query:
        try:
            campaign_id = int(query.split()[-1])
            return calculate_roi(campaign_id)
        except ValueError:
            return "Please provide a valid campaign ID."
    elif "average conversion rate" in query:
        channel = query.split()[-1]
        return average_conversion_rate(channel)
    elif "highest engagement" in query:
        segment = " ".join(query.split()[4:])
        return highest_engagement_score(segment)
    return "I am not sure how to answer that. Please ask about ROI, conversion rate, or engagement."


if __name__ == "__main__":
    while True:
        query = input("Ask a question (or type 'exit' to quit): ")
        if query.lower() == 'exit':
            break
        print(bot_response(query))
