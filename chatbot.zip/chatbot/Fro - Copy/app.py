from flask import Flask, render_template, request
import pandas as pd
from transformers import pipeline
import spacy
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

# Initialize Flask app
app = Flask(__name__)

# Suppress warnings
warnings.filterwarnings("ignore", message="The `clean_up_tokenization_spaces`")

# Load Spacy NLP model for question filtering
nlp_spacy = spacy.load("en_core_web_sm")

# Load dataset
df = pd.read_csv('marketing_campaign_dataset_first2K.csv')
df.columns = df.columns.str.strip()
df['Acquisition_Cost'] = df['Acquisition_Cost'].replace({'\$': '', ',': ''}, regex=True).astype(float)

# Initialize the question-answering pipeline
qa_model = pipeline('question-answering', model='distilbert-base-uncased-distilled-squad')

# Cache for previous responses
response_cache = {}

# Function to generate a focused context
def generate_context(filtered_df):
    filtered_df = filtered_df.head(10)
    context = "\n".join(
        f"Campaign ID {row['Campaign_ID']} by {row['Company']} is a {row['Campaign_Type']} campaign "
        f"targeted at {row['Target_Audience']} for {row['Duration']} days. It was conducted in "
        f"{row['Location']} using {row['Channel_Used']}. The campaign had a conversion rate of "
        f"{row['Conversion_Rate']}, an acquisition cost of ${row['Acquisition_Cost']:.2f}, and "
        f"a ROI of {row['ROI']:.2f}."
        for _, row in filtered_df.iterrows()
    )
    return context

# Function to extract an answer based on the question
def extract_answer(question):
    if question in response_cache:
        return response_cache[question]

    # Generate context from dataset
    filtered_context = generate_context(df)
    result = qa_model(question=question, context=filtered_context)

    if result['score'] > 0.1:
        response_cache[question] = result['answer']
    else:
        response_cache[question] = "That's an interesting question! Have you considered how changing the campaign type affects the ROI?"

    return response_cache[question]

# Function to handle stats
def handle_stats():
    average_roi = df['ROI'].mean()
    average_acquisition_cost = df['Acquisition_Cost'].mean()
    return f"Average ROI: {average_roi:.2f}, Average Acquisition Cost: ${average_acquisition_cost:.2f}"

# Function to handle summary
def handle_summary():
    campaign_types = df['Campaign_Type'].value_counts()
    summary = "Campaign Summary:\n" + "\n".join([f"{camp_type}: {count}" for camp_type, count in campaign_types.items()])
    return summary

# Function to handle trends
def handle_trends():
    # Plot ROI vs. Campaign Type
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Campaign_Type', y='ROI', data=df, ci=None)
    plt.xticks(rotation=45)
    plt.title('ROI by Campaign Type')

    # Save plot to a string buffer and return image in base64 format
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    plot_url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return f'<img src="data:image/png;base64,{plot_url}" alt="Trends Graph">'

# Function to handle filter
def handle_filter():
    influencer_campaigns = df[df['Campaign_Type'] == 'Influencer Marketing Campaign']
    highest_conversion_rate = influencer_campaigns['Conversion_Rate'].max()
    highest_conversion_campaign = influencer_campaigns[influencer_campaigns['Conversion_Rate'] == highest_conversion_rate]

    if not highest_conversion_campaign.empty:
        return highest_conversion_campaign.to_html()
    else:
        return "No influencer campaigns found with a conversion rate."

# Function to handle sentiment (placeholder for now)
def handle_sentiment():
    return "Sentiment analysis is not yet implemented."

# Route for home page
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle user question and respond
@app.route('/answer', methods=['POST'])
def answer():
    user_input = request.form['user_input']

    # Handling special keywords
    if user_input.lower() == 'exit':
        response = "Goodbye!"
    elif user_input.lower() == 'stats':
        response = handle_stats()
    elif user_input.lower() == 'summary':
        response = handle_summary()
    elif user_input.lower() == 'trends':
        response = handle_trends()
    elif user_input.lower() == 'filter':
        response = handle_filter()
    elif user_input.lower() == 'sentiment':
        response = handle_sentiment()
    else:
        # For other inputs, use the question-answering model
        response = extract_answer(user_input)

    return render_template('index.html', response=response, user_input=user_input)

if __name__ == '__main__':
    app.run(debug=True)
